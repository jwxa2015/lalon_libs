from _cairo import *
