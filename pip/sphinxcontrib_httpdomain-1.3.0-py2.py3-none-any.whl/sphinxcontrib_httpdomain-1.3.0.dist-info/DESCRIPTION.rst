
This contrib extension, sphinxcontrib.httpdomain provides a Sphinx
domain for describing RESTful HTTP APIs.

You can find the documentation from the following URL:

http://pythonhosted.org/sphinxcontrib-httpdomain/


