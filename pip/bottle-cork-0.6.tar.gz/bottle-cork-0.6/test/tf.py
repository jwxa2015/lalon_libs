
class Test(object):
    def test_fun1(self):
        assert False, 'yoo'

