============================
HTTP client/server utilities
============================

.. automodule:: webtest.http

.. autoclass:: StopableWSGIServer
   :members:

.. autofunction:: check_server

