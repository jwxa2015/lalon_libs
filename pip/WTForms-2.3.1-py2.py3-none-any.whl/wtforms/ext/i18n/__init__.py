import warnings

warnings.warn(
    "'wtforms.ext.i18n' will be removed in WTForms 3.0. It is built-in"
    " to WTForms core now.",
    DeprecationWarning,
)
