import warnings

warnings.warn(
    "'wtforms.ext.appengine' will be removed in WTForms 3.0. Use"
    " wtforms-appengine instead."
    " https://github.com/wtforms/wtforms-appengine",
    DeprecationWarning,
)
