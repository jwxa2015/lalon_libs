from hamcrest.core.assert_that import assert_that
from hamcrest.core.core import *

__author__ = "Jon Reid"
__copyright__ = "Copyright 2011 hamcrest.org"
__license__ = "BSD, see License.txt"
