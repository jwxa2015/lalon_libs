
try:
    from unittest import mock
except ImportError:
    from mock import mock


__all__ = ['mock']
