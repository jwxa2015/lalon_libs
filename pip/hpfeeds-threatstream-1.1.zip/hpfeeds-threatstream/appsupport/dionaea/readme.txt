- update conf/dionaea.conf.dist to include the new section and enable hpfeeds ihandler
- update modules/python/scripts/ihandlers.py to load hpfeeds ihandler
- add modules/python/scripts/hpfeeds.py

