hpfeeds-client
==============

## CLI util

```
hpfeeds-client
Usage: hpfeeds-client -i ident -s secret --host host -p port -c channel1 [-c channel2, ...] <action> [<data>]

hpfeeds-client: error: You need to give "subscribe" or "publish" as <action>.
```

