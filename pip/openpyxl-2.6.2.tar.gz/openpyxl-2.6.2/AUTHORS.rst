This project was started by Eric Gazoni. In 2013 Charlie Clark became
co-maintainer of the project.

It was initially *heavily* inspired by the PHPExcel library:
http://www.phpexcel.net/

Thanks to all those who participate in the project (in alphabetical order):

* aceMueller
* Adam Lofts
* Adam Morris
* Alessandro Cucci
* Alex Gronholm
* Alexandre Fayolle
* Amin Mirzaee
* Anders Chrigstrom
* Bernt R. Brenna
* Brent Hoover
* Brice Gelineau
* ccoacley
* Chi Ho Kwok
* Cory Kramer
* Day Barr
* Detlef Lannert
* Dieter Vandenbussche
* Dmitriy Chernyshov
* Dominik Geldmacher
* Don Freeman
* Elias Rabel
* Eric Chlebek
* Eric Gazoni
* Eric Hurkman
* Etienne Desautels
* Felipe Ochoa
* Felix Siebeneicker
* Fumito Hamamura
* Gabi Nagy
* Gar Thompson
* Gerald Van Huffelen
* Greg Lehmann
* Heikki Junes
* Israel Barth Rubio
* James Smagala
* JarekPS
* Jean Pierre Huart
* Jeff Holman
* Jonathan Peirce
* Joseph Tate
* Josh Haywood
* Jun Omae
* Kay Webber
* Khchine Hamza
* Klaus Bremer
* Koert van der Veer
* Laurent Laporte
* Laurent Vasseur
* Maarten De Paepe
* Magnus Schieder
* Mark Gemmill
* Marko Loparic
* Masato Yoshida
* Max Bolingbroke
* Nicholas Laver
* Paul Joyce
* Paul Van Der Linden
* Philip Roche
* ramn_se
* Rick Rankin
* Samuel Loretan
* Sergey Pikhovkin
* Shibukawa Yoshiki
* Stefan Behnel
* Stephane Bard
* Stephen Rauch
* Sven Burk
* Ted Pollari
* Thomas Nygards
* Waldemar Osuch
* Wojciech Rola
* Wolfgane Scherer
* Yaroslav Halchenko
* Yingjie Lan
* Leetao

Project logo designed by Eric Gazoni, font by claudeserieux
(http://www.dafont.com/profile.php?user=337503)
