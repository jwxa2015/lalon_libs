evnet
===========
Efficient non-blocking/asynchronous networking library built on top of libev through its pyev bindings.

## Getting Started

See examples/.

## Learn More

  - [libev](http://software.schmorp.de/pkg/libev.html)
  - [pyev](http://code.google.com/p/pyev/)
  - [Repository at github](http://github.com/rep/evnet)

